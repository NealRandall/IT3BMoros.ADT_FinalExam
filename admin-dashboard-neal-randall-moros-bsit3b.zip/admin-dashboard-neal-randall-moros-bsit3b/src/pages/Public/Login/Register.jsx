import { useState, useRef } from 'react';
import './Register.css';
import { useNavigate } from 'react-router-dom';
import { useDebounce } from '../../../utils/hooks/useDebounce';
import axios from 'axios';

function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [isShowPassword, setIsShowPassword] = useState(false);
  const [isFieldsDirty, setIsFieldsDirty] = useState(false);
  
  const navigate = useNavigate();
  const passwordRef = useRef();

  const handleChange = (event) => {
    const { name, value } = event.target;

    switch (name) {
      case 'email':
        setEmail(value);
        break;
      case 'password':
        setPassword(value);
        break;
      case 'firstName':
        setFirstName(value);
        break;
      case 'middleName':
        setMiddleName(value);
        break;
      case 'lastName':
        setLastName(value);
        break;
      case 'contactNumber':
        setContactNumber(value);
        break;
      default:
        break;
    }

    setIsFieldsDirty(true);
  };

  const handleShowPassword = () => {
    setIsShowPassword((prev) => !prev);
  };

  const handleRegister = async () => {
    const data = {
      email,
      password,
      firstName,
      middleName,
      lastName,
      contactNumber,
    };

    try {
      const res = await axios.post('/admin/register', data);
      console.log(res);
      navigate('/login');
    } catch (error) {
      console.error("Registration error:", error.response ? error.response.data : error.message);
    }
  };

  return (
    <div className='Register'>
      <div className='main-container'>
        <h3>Register</h3>
        <form>
          <div className='form-container'>
            <div className='form-group'>
              <label>First Name:</label>
              <input
                type='text'
                name='firstName'
                value={firstName}
                onChange={handleChange}
              />
              {isFieldsDirty && firstName === '' && (
                <span className='errors'>This field is required</span>
              )}
            </div>
            <div className='form-group'>
              <label>Middle Name:</label>
              <input
                type='text'
                name='middleName'
                value={middleName}
                onChange={handleChange}
              />
            </div>
            <div className='form-group'>
              <label>Last Name:</label>
              <input
                type='text'
                name='lastName'
                value={lastName}
                onChange={handleChange}
              />
              {isFieldsDirty && lastName === '' && (
                <span className='errors'>This field is required</span>
              )}
            </div>
            <div className='form-group'>
              <label>Contact Number:</label>
              <input
                type='text'
                name='contactNumber'
                value={contactNumber}
                onChange={handleChange}
              />
            </div>
            <div className='form-group'>
              <label>E-mail:</label>
              <input
                type='text'
                name='email'
                value={email}
                onChange={handleChange}
              />
              {isFieldsDirty && email === '' && (
                <span className='errors'>This field is required</span>
              )}
            </div>
            <div className='form-group'>
              <label>Password:</label>
              <input
                type={isShowPassword ? 'text' : 'password'}
                name='password'
                value={password}
                onChange={handleChange}
                ref={passwordRef}
              />
              {isFieldsDirty && password === '' && (
                <span className='errors'>This field is required</span>
              )}
            </div>
            <div className='show-password' onClick={handleShowPassword}>
              {isShowPassword ? 'Hide' : 'Show'} Password
            </div>

            <div className='submit-container'>
              <button type='button' onClick={handleRegister}>
                Register
              </button>
            </div>
            <div className='login-container'>
              <a href='/login'>
                <small>Already have an account? Login</small>
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Register;
